'use client';

import { useState, useEffect, useMemo, useCallback, type ChangeEvent } from 'react';
import {
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper,
  TextField, Select, MenuItem, IconButton, Button, CircularProgress, Alert,
  Typography
} from '@mui/material';
import { Edit, Delete, Add, EditNote } from '@mui/icons-material';
import GroupsIcon from '@mui/icons-material/Groups';
import { useProjects } from '../context/ProjectContext';
import { GlobalCollaborator, MedicoRole, ScoringParametersByPeriod, ShiftHours, WorkPeriod } from '@/types/project';
import CollaboratorModal from './modal/AddCollaboratorModal';
import AddExistingCollaboratorModal from './modal/AddExistingCollaboratorModal';
import EquipeSupervisorModal from './modal/EquipeSupervisorModal';
import styles from './styles/CollaboratorsPanel.module.css';
import ScoringParamsModal from './modal/ScoringParamsModal';
import DataForPointsModal from './modal/DataForPointsModal';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import UploadWarningsModal from './modal/UploadWarningsModal';
import { formatSecondsToTime, formatWorkPeriod, is24hCollaborator } from './utils';


export type CombinedCollaboratorData = Omit<GlobalCollaborator, 'isGlobal'> & {
  isGlobal: boolean;
  projectId?: string;
  medicoRole?: MedicoRole;
  shiftHours?: ShiftHours;
  // undefined = colaborador 24h (Supervisor, ou Médico Líder/Regulador com turno H24).
  workPeriod?: WorkPeriod;
  points?: Record<string, number>;
  equipeIds?: string[];
};

const PERIOD_24H = '24H' as const;
type PeriodFilter = 'all' | WorkPeriod | typeof PERIOD_24H;

export default function CollaboratorsPanel() {
  const {
    selectedProject,
    projects,
    projectCollaborators,
    globalCollaborators,
    actions: { addCollaboratorToProject, deleteCollaboratorFromProject, fetchProjectCollaborators, updateProjectParameters, updateProjectCollaboratorEquipe }
  } = useProjects();

  // Estados
  const [state, setState] = useState({
    searchTerm: '',
    filterRole: 'all' as 'all' | string,
    filterPeriod: 'all' as PeriodFilter,
    roles: [] as string[],
    medicoRole: [] as MedicoRole[],
    error: null as string | null,
    loading: false,
    panelLoading: false,
    scoringParamsModalOpen: false,
    isAddExistingModalOpen: false,
  });


  const [editingCollaboratorInitialData, setEditingCollaboratorInitialData] = useState<CombinedCollaboratorData | undefined>();
  const [editingCollaboratorPointsData, setEditingCollaboratorPointsData] = useState<CombinedCollaboratorData | undefined>();
  const [equipeCollaborator, setEquipeCollaborator] = useState<CombinedCollaboratorData | undefined>();

  // Atualização de estado simplificada
  const updateState = (newState: Partial<typeof state>) => setState(prev => ({ ...prev, ...newState }));
  const currentProject = projects.find(p => p.id === selectedProject);

  const [uploadWarnings, setUploadWarnings] = useState<string[]>([]);
  const [isWarningModalOpen, setIsWarningModalOpen] = useState(false);


  // Efeitos
  useEffect(() => {
    if (selectedProject) {
      fetchProjectCollaborators(selectedProject)
        .catch(() => updateState({ error: 'Falha ao carregar colaboradores do projeto' }));
    }
  }, [selectedProject, fetchProjectCollaborators]);


  useEffect(() => {
    if (selectedProject) {
      const inProject = projectCollaborators[selectedProject] || [];
      updateState({ roles: Array.from(new Set(inProject.map(c => c.role))) });
      updateState({ medicoRole: Array.from(new Set(inProject.map(c => c.medicoRole))).filter((mr): mr is MedicoRole => mr !== undefined && mr !== ("NENHUM" as MedicoRole)) });
    }
  }, [projectCollaborators, selectedProject]);

  // Dados processados
  const combinedCollaborators = useMemo(() => {
    if (!selectedProject) return [];

    return (projectCollaborators[selectedProject] || []).map(pc => {
      const gc = globalCollaborators?.find(g => g.id === pc.id);
      return {
        id: pc.id,
        nome: pc?.nome || gc?.nome || "-",
        cpf: pc?.cpf || gc?.cpf || "000-000-00-00",
        idCallRote: pc?.idCallRote || gc?.idCallRote || "0000",
        role: pc.role,
        pontuacao: pc.pontuacao,
        isGlobal: gc?.isGlobal ?? false,
        projectId: selectedProject,

        removidos: pc.removidos,
        removidosLider: pc.removidosLider,
        duration: pc.durationSeconds,
        criticos: pc.criticos,
        pausaMensal: pc.pausaMensalSeconds,
        saidaVtr: pc.saidaVtr,

        medicoRole: pc.medicoRole || gc?.medicoRole,
        shiftHours: pc.shiftHours || gc?.shiftHours,
        workPeriod: is24hCollaborator(pc.role, pc.medicoRole || gc?.medicoRole, pc.shiftHours || gc?.shiftHours)
          ? undefined
          : (pc.workPeriod || gc?.workPeriod || WorkPeriod.DIURNO),

        points: pc.points || {},
        equipeIds: pc.equipeIds || [],
      };
    });
  }, [projectCollaborators, globalCollaborators, selectedProject]);

  // Candidatos pra compor a equipe de um supervisor NESTE projeto: só quem já
  // está adicionado ao projeto (TARM/Frota/Médico).
  const equipeCandidatosDoProjeto = useMemo(() =>
    combinedCollaborators
      .filter(c => c.role === 'TARM' || c.role === 'FROTA' || c.role === 'MEDICO')
      .map(c => ({ id: c.id!, nome: c.nome, role: c.role, medicoRole: c.medicoRole, shiftHours: c.shiftHours })),
    [combinedCollaborators]
  );

  const filteredCollaborators = useMemo(() =>
    combinedCollaborators
      .filter(c =>
        c.nome.toLowerCase().includes(state.searchTerm.toLowerCase()) &&
        (state.filterRole === 'all' || c.role === state.filterRole || c.medicoRole === state.filterRole) &&
        (state.filterPeriod === 'all'
          || (state.filterPeriod === PERIOD_24H
            ? is24hCollaborator(c.role, c.medicoRole, c.shiftHours)
            : c.workPeriod === state.filterPeriod))
      )
      .sort((a, b) => a.nome.localeCompare(b.nome)),
    [combinedCollaborators, state.searchTerm, state.filterRole, state.filterPeriod]
  );

  const availableCollaborators = useMemo(() => {
    if (!globalCollaborators || !selectedProject) return [];
    const inProjectIds = new Set((projectCollaborators[selectedProject] || []).map(c => c.id));
    return globalCollaborators.filter(gc => !inProjectIds.has(gc.id));
  }, [globalCollaborators, projectCollaborators, selectedProject]);

  // Handlers
  const handleDelete = useCallback(async (id: string) => {
    if (!selectedProject) return;

    updateState({ panelLoading: true, error: null });

    try {
      await deleteCollaboratorFromProject(selectedProject, id);
      await fetchProjectCollaborators(selectedProject);
    } catch (err: any) {
      updateState({ error: err.response?.data?.message || 'Falha ao excluir colaborador' });
    } finally {
      updateState({ panelLoading: false });
    }
  }, [selectedProject, deleteCollaboratorFromProject, fetchProjectCollaborators]);

  const handleAddExisting = useCallback(async (id: string, role: string, medicoRole?: MedicoRole, shiftHours?: ShiftHours) => {
    if (!selectedProject) return;

    updateState({ panelLoading: true, error: null });

    try {
      const globalCollab = globalCollaborators?.find(gc => gc.id === id);
      if (!globalCollab) throw new Error('Colaborador global não encontrado');

      if (role === 'MEDICO' && (!medicoRole || !shiftHours)) {
        throw new Error('Para a função MEDICO, o Papel Médico e o Turno são obrigatórios.');
      }

      await addCollaboratorToProject(selectedProject, {
        id, nome: globalCollab.nome, role,
        medicoRole: medicoRole as MedicoRole,
        shiftHours: shiftHours as ShiftHours,
        workPeriod: is24hCollaborator(role, medicoRole, shiftHours)
          ? undefined
          : (globalCollab.workPeriod || WorkPeriod.DIURNO)
      });

      await fetchProjectCollaborators(selectedProject);
      updateState({ isAddExistingModalOpen: false });
    } catch (err: any) {
      updateState({ error: err.response?.data?.message || err.message || 'Falha ao adicionar colaborador' });
    } finally {
      updateState({ panelLoading: false });
    }
  }, [selectedProject, addCollaboratorToProject, fetchProjectCollaborators, globalCollaborators]);

  const handleUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.length || !selectedProject) return;

    updateState({ loading: true, error: null });

    const formData = new FormData();
    formData.append('arquivo', e.target.files[0], e.target.files[0].name);

    try {
      const response = await fetch(
        `/api/proxy/${selectedProject}/processar`,
        {
          method: 'POST',
          body: formData,
          headers: {
            'Accept': 'application/json',
          },
        }
      );

      const responseText = await response.text();
      let responseData: any = null;

      if (responseText) {
        try {
          responseData = JSON.parse(responseText);
        } catch {
          responseData = responseText;
        }
      }

      const parsedMessage = Array.isArray(responseData)
        ? responseData[0]
        : typeof responseData === 'object'
          ? responseData?.message || responseData?.error || responseData?.details || null
          : responseData;

      if (!response.ok) {
        throw new Error(parsedMessage || `Erro ${response.status}: ${response.statusText}`);
      }

      // Verificar se a resposta contém mensagens de alerta
      if (Array.isArray(responseData) && responseData.length > 0) {
        setUploadWarnings(responseData);
        setIsWarningModalOpen(true);
      }

      await fetchProjectCollaborators(selectedProject);
    } catch (err: any) {
      updateState({
        error: err.message.includes('Failed to fetch')
          ? 'Falha na conexão com o servidor'
          : err.message
      });
    } finally {
      updateState({ loading: false });
    }
  };

  const extractCollaboratorFromWarning = (warning: string): CombinedCollaboratorData | undefined => {
    // Extrai o nome cadastrado (antes do parêntese)
    const match = warning.match(/^([^(]+) \(/);
    if (match) {
      const nomeCadastrado = match[1].trim();

      // Busca exata pelo nome cadastrado
      return combinedCollaborators.find(c =>
        c.nome.toLowerCase() === nomeCadastrado.toLowerCase()
      );
    }

    return undefined;
  };

  const handleEditCollaboratorFromWarning = (warning: string) => {
    const collaborator = extractCollaboratorFromWarning(warning);
    if (collaborator) {
      setEditingCollaboratorInitialData(collaborator);
    } else {
      // Tenta extrair o nome para mostrar na mensagem de erro
      const nomeCadastrado = warning.match(/^([^(]+) \(/)?.[1]?.trim() || warning;
      updateState({
        error: `Não foi possível encontrar o colaborador "${nomeCadastrado}" na lista de colaboradores do projeto.`
      });
    }
  };

  const refreshCollaborators = async () => {
    if (selectedProject) {
      try {
        await fetchProjectCollaborators(selectedProject);
      } catch (err: any) {
        const errorMessage =
          err.response?.data?.message ||
          err.message ||
          'Erro ao salvar colaborador';
        updateState({ error: errorMessage });
      }
    }
  };

  const handleSaveParameters = async (params: ScoringParametersByPeriod) => {
    if (!selectedProject) return;

    updateState({ panelLoading: true, error: null });

    try {
      await updateProjectParameters(selectedProject, params);
      await fetchProjectCollaborators(selectedProject);
      updateState({ scoringParamsModalOpen: false });
    } catch (err: any) {
      updateState({ error: err.response?.data?.message || 'Falha ao salvar parâmetros' });
    } finally {
      updateState({ panelLoading: false });
    }
  };

  const handleExport = () => {
    if (!combinedCollaborators || combinedCollaborators.length === 0) {
      console.error("Nenhum colaborador para exportar.");
      return;
    }

    // Agrupa por função, mas para médicos consideramos também o papel (LIDER ou REGULADOR)
    const collaboratorsByRole = combinedCollaborators
      .sort((a, b) => a.nome.localeCompare(b.nome))
      .reduce((acc, c) => {
        // define a chave da sheet
        let sheetKey = c.role;
        if (c.role === 'MEDICO' && c.medicoRole) {
          sheetKey = `MEDICO_${c.medicoRole}`; // ex: "MEDICO_LIDER" ou "MEDICO_REGULADOR"
        }

        if (!acc[sheetKey]) {
          acc[sheetKey] = [];
        }
        acc[sheetKey].push(c);
        return acc;
      }, {} as Record<string, typeof combinedCollaborators>);

    const wb = XLSX.utils.book_new();

    Object.entries(collaboratorsByRole).forEach(([sheetKey, collabs]) => {
      const sheetData = collabs.map(c => {
        const baseData: Record<string, any> = {
          'Função': c.role === 'MEDICO' && c.medicoRole && c.shiftHours
            ? `${c.role} (${c.medicoRole} - ${c.shiftHours})`
            : c.role,
          'Nome': c.nome,
          'Período': formatWorkPeriod(c.role, c.medicoRole, c.shiftHours, c.workPeriod),
          'Pausa Mensal': formatSecondsToTime(c.pausaMensal),
          'Pausa Pontos': c.points?.['Pausas'] || 0,

        };

        if (sheetKey.startsWith("FROTA")) {
          baseData['Saída VTR'] = formatSecondsToTime(c.saidaVtr);
          baseData['Saída VTR Pontos'] = c.points?.['SaidaVTR'] || 0;
        }

        if (c.role === 'MEDICO' && c.medicoRole === MedicoRole.LIDER) {
          baseData['Críticos'] = formatSecondsToTime(c.criticos);
          baseData['Críticos Pontos'] = c.points?.['Criticos'] || 0;
        }
        if (c.medicoRole !== MedicoRole.LIDER) {
          baseData['Regulação'] = formatSecondsToTime(c.duration);
          baseData['Regulação Pontos'] = c.points?.['Regulacao'] || 0;
        }
        if (c.medicoRole === MedicoRole.LIDER) {
          baseData['Removidos Líder'] = c.removidosLider || 0;
          baseData['Removidos Líder Pontos'] = c.points?.['RemovidosLider'] || 0;
        }
        if (sheetKey !== "FROTA" && c.medicoRole !== MedicoRole.LIDER) {
          baseData['Removidos'] = c.removidos;
          baseData['Removidos Pontos'] = c.points?.['Removidos'] || 0;
        }
        baseData['Pontuação'] = c.pontuacao;

        return baseData;
      });

      const ws = XLSX.utils.json_to_sheet(sheetData);
      // torna o nome seguro e curto (<=31 caracteres) para o Excel
      const safeSheetName = sheetKey.substring(0, 31).replace(/[:\\/?*\[\]]/g, '');
      XLSX.utils.book_append_sheet(wb, ws, safeSheetName);
    });

    const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    const fileName = currentProject
      ? `${currentProject.name}_${currentProject.month}_colaboradores_por_funcao.xlsx`
      : 'colaboradores_por_funcao.xlsx';
    saveAs(new Blob([wbout]), fileName);
  };

  const isTableLoading = selectedProject && !projectCollaborators[selectedProject];

  return (
    <div className={styles.panel}>
      {!selectedProject ? <p>Selecione um projeto.</p> : (
        <>
          {state.error && (
            <Alert severity="error" onClose={() => updateState({ error: null })} sx={{ mb: 2 }}>
              {state.error}
            </Alert>
          )}
          <Typography sx={{ marginBottom: 3 }}>Projeto: {currentProject?.name || '—'}</Typography>

          <div className={styles.filters}>
            <TextField
              placeholder="Pesquisar"
              size="small"
              fullWidth
              value={state.searchTerm}
              onChange={e => updateState({ searchTerm: e.target.value, error: null })}
            />

            <Select
              value={state.filterRole}
              size="small"
              onChange={e => updateState({ filterRole: e.target.value as string, error: null })}
            >
              <MenuItem value="all">Todas funções</MenuItem>
              {state.roles.map(role => (
                <MenuItem key={role} value={role}>{role}</MenuItem>
              ))}
              {state.medicoRole.map(Mrole => (
                <MenuItem key={Mrole} value={Mrole}>{Mrole}</MenuItem>
              ))}

            </Select>
            <Select
              value={state.filterPeriod}
              size="small"
              onChange={e => updateState({ filterPeriod: e.target.value as PeriodFilter, error: null })}
            >
              <MenuItem value="all">Todos os períodos</MenuItem>
              <MenuItem value={WorkPeriod.DIURNO}>Diurno</MenuItem>
              <MenuItem value={WorkPeriod.NOTURNO}>Noturno</MenuItem>
              <MenuItem value={PERIOD_24H}>24h</MenuItem>
            </Select>
          </div>

          <div className={styles.actionButtons}>
            <Button
              variant="contained"
              color="warning"
              startIcon={<Add />}
              onClick={() => updateState({ isAddExistingModalOpen: true })}
              sx={{ borderRadius: '20px' }}
              disabled={state.panelLoading}
            >
              Adicionar Existente
            </Button>

            <Button
              variant="contained"
              color="warning"
              onClick={() => updateState({ scoringParamsModalOpen: true })}
              sx={{ borderRadius: '20px' }}
              disabled={state.panelLoading}
            >
              Configurar Parâmetros
            </Button>

            <Button
              variant="contained"
              color="success"
              component="label"
              sx={{ borderRadius: '20px' }}
              disabled={state.loading}
            >
              {state.loading ? 'Enviando...' : 'Enviar Planilha'}
              <input type="file" hidden accept=".xlsx,.xls" onChange={handleUpload} />
            </Button>
            <Button
              variant="contained"
              color="success"
              component="label"
              sx={{ borderRadius: '20px' }}
              disabled={state.loading}
              onClick={handleExport}
            >
              Exportar Excel
            </Button>
          </div>

          <TableContainer component={Paper} className={styles.tableContainer}>
            <Table stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell>Nome</TableCell>
                  <TableCell>Função</TableCell>
                  <TableCell>Período</TableCell>
                  <TableCell>Pontuação</TableCell>
                  <TableCell>Ações</TableCell>
                </TableRow>
              </TableHead>

              <TableBody>
                {isTableLoading ? (
                  <TableRow>
                    <TableCell colSpan={5} align="center"><CircularProgress /></TableCell>
                  </TableRow>
                ) : filteredCollaborators.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} align="center">Nenhum colaborador encontrado</TableCell>
                  </TableRow>
                ) : (
                  filteredCollaborators.map(c => (
                    <TableRow key={c.id}>
                      <TableCell>{c.nome}</TableCell>
                      <TableCell>
                        {c.role}
                        {c.role === 'MEDICO' && c.medicoRole && c.shiftHours
                          ? ` (${c.medicoRole} - ${c.shiftHours})` : ''}
                      </TableCell>
                      <TableCell>{formatWorkPeriod(c.role, c.medicoRole, c.shiftHours, c.workPeriod)}</TableCell>
                      <TableCell>{c.pontuacao}</TableCell>
                      <TableCell>
                        <IconButton
                          onClick={() => setEditingCollaboratorInitialData(c)}
                          disabled={state.panelLoading}
                          title="Editar colaborador"
                        >
                          <Edit color='primary' />
                        </IconButton>

                        <IconButton
                          onClick={() => setEditingCollaboratorPointsData(c)}
                          disabled={state.panelLoading}
                          title="Editar dados para pontuação"
                        >
                          <EditNote color='success' />
                        </IconButton>

                        {c.role === 'SUPERVISOR' && (
                          <IconButton
                            onClick={() => setEquipeCollaborator(c)}
                            disabled={state.panelLoading}
                            title="Equipe do supervisor neste projeto"
                          >
                            <GroupsIcon color="action" />
                          </IconButton>
                        )}

                        {/* NOVO: Atualize o onClick para abrir o diálogo */}
                        <IconButton
                          onClick={() => handleDelete(c.id!)}
                          disabled={state.panelLoading}
                          title="Remover colaborador"
                        >
                          {state.panelLoading ? <CircularProgress size={24} /> : <Delete color="error" />}
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>

          {/* Modais */}
          <ScoringParamsModal
            open={state.scoringParamsModalOpen}
            onClose={() => updateState({ scoringParamsModalOpen: false })}
            onSave={handleSaveParameters}
            initialParams={currentProject?.scoringParameters}
          />

          <DataForPointsModal
            open={!!editingCollaboratorPointsData}
            onClose={() => setEditingCollaboratorPointsData(undefined)}
            onSuccess={() => { refreshCollaborators(); setEditingCollaboratorPointsData(undefined); }}
            initialData={editingCollaboratorPointsData}
            projectId={selectedProject}
          />

          <CollaboratorModal
            open={!!editingCollaboratorInitialData}
            onClose={() => setEditingCollaboratorInitialData(undefined)}
            onSuccess={() => { refreshCollaborators(); setEditingCollaboratorInitialData(undefined); }}
            initialData={editingCollaboratorInitialData}
            projectId={selectedProject}
          />

          <AddExistingCollaboratorModal
            open={state.isAddExistingModalOpen}
            onClose={() => updateState({ isAddExistingModalOpen: false })}
            collaborators={availableCollaborators}
            onAdd={handleAddExisting}
            loading={state.panelLoading}
          />
          <UploadWarningsModal
            open={isWarningModalOpen}
            warnings={uploadWarnings}
            onClose={() => setIsWarningModalOpen(false)}
            onEditCollaborator={handleEditCollaboratorFromWarning}
          />

          <EquipeSupervisorModal
            open={!!equipeCollaborator}
            onClose={() => setEquipeCollaborator(undefined)}
            supervisorNome={equipeCollaborator?.nome || ''}
            initialSelectedIds={equipeCollaborator?.equipeIds || []}
            candidatos={equipeCandidatosDoProjeto}
            escopoDescricao="Esta equipe vale só para este projeto (o cadastro global do supervisor não é alterado)."
            onSave={async (equipeIds) => {
              if (!selectedProject || !equipeCollaborator?.id) return;
              await updateProjectCollaboratorEquipe(selectedProject, equipeCollaborator.id, equipeIds);
            }}
          />

        </>
      )}
    </div>
  );
}

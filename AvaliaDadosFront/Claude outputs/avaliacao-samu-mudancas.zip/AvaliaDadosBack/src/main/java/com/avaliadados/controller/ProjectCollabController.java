package com.avaliadados.controller;

import com.avaliadados.model.dto.CollaboratorsResponse;
import com.avaliadados.model.dto.ProjectCollabRequest;
import com.avaliadados.model.ProjetoEntity;
import com.avaliadados.service.ProjectCollabService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/projetos/{projectId}/collaborator")
@RequiredArgsConstructor
@Tag(name = "Collaboradores do Projeto", description = "Operações relacionadas aos colaboradores de um projeto")
public class ProjectCollabController {

    private final ProjectCollabService service;

    @PostMapping
    @Operation(summary = "Adiciona um colaborador ao projeto")
    public ResponseEntity<ProjetoEntity> add(
            @PathVariable String projectId, @RequestBody ProjectCollabRequest dto) {

        return ResponseEntity.ok(service.addCollaborator(projectId, dto));
    }

    @GetMapping
    @Operation(summary = "Busca todos os colaboradores do projeto")
    public ResponseEntity<List<CollaboratorsResponse>> getAll(@PathVariable String projectId) {

        List<CollaboratorsResponse> collaborators = service.getAllProjectCollaborators(projectId);
        return ResponseEntity.ok(collaborators);
    }

    @PutMapping("/{collaboratorId}")
    @Operation(summary = "Atualiza um colaborador do projeto")
    public ResponseEntity<ProjetoEntity> update(@PathVariable String projectId, @PathVariable String collaboratorId, @RequestBody ProjectCollabRequest dto, @RequestParam Boolean wasEdited) {

        return ResponseEntity.ok(service.updateProjectCollaborator(
                projectId,
                collaboratorId,
                dto,
                wasEdited
        )
        );
    }

    @PutMapping("/{collaboratorId}/equipe")
    @Operation(summary = "Atualiza a equipe do supervisor só neste projeto")
    public ResponseEntity<ProjetoEntity> updateEquipe(
            @PathVariable String projectId,
            @PathVariable String collaboratorId,
            @RequestBody EquipeRequest request) {
        return ResponseEntity.ok(service.updateEquipe(projectId, collaboratorId, request.equipeIds()));
    }

    public record EquipeRequest(List<String> equipeIds) {}

    @DeleteMapping("/{collaboratorId}")
    @Operation(summary = "Remove um colaborador do projeto")
    public ResponseEntity<Void> delete(
            @PathVariable String projectId,
            @PathVariable String collaboratorId
    ) {
        service.removeCollaborator(projectId, collaboratorId);
        return ResponseEntity.noContent().build();
    }
}
